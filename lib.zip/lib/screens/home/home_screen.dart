// lib/screens/home/home_screen.dart
import 'dart:convert';
import 'dart:ui' show ImageFilter;
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../../widgets/glass_card.dart';

// utils
import '../../utils/role_storage.dart';
import '../../utils/profile_storage.dart';
import '../../utils/user_role.dart';

// services
import '../../services/fitstreet_api.dart';

// screens referenced from the home screen
import '../trainers/trainer_list_screen.dart';
import '../bookings/booking_screen.dart';
import '../diet/diet_screen.dart';
import '../counsellors/counsellor_screen.dart';
import '../trainers/trainer_profile_screen.dart';
import '../user/profile_completion_wizard.dart';
import '../User/profile_fill_screen.dart';

// NEW: use the styled login screen
import '../login/login_screen_styled.dart';
import '../../state/auth_manager.dart';
import '../../config/app_colors.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> with SingleTickerProviderStateMixin {
  bool _profileComplete = false;
  bool _loadingProfileState = true;
  UserRole _role = UserRole.unknown;
  String _greetingName = '';

  // ===== Notifications (USER) =====
  int _notificationCount = 0;
  List<dynamic> _notifications = [];
  bool _loadingNotifications = false;
  OverlayEntry? _notifEntry;

  final GlobalKey<ScaffoldState> _scaffoldKey = GlobalKey<ScaffoldState>();

  // Subtle liquid glass animation controller
  late final AnimationController _liquidCtrl;

  void _onAuthChanged() {
    _loadProfileState();
    _fetchNotificationsIfLoggedIn();
  }

  @override
  void initState() {
    super.initState();
    _liquidCtrl = AnimationController(vsync: this, duration: const Duration(seconds: 16))..repeat();
    _loadProfileState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final auth = context.read<AuthManager?>();
      auth?.addListener(_onAuthChanged);
      _fetchNotificationsIfLoggedIn();
    });
  }

  @override
  void dispose() {
    try {
      final auth = context.read<AuthManager?>();
      auth?.removeListener(_onAuthChanged);
    } catch (_) {}
    try {
      _liquidCtrl.dispose();
    } catch (_) {}
    try {
      _hideNotificationOverlay();
    } catch (_) {}
    super.dispose();
  }

  Future<void> _loadProfileState() async {
    final role = await getUserRole();
    final done = await getProfileComplete();
    final name = await getUserName();
    final mobile = await getMobile();

    if (!mounted) return;
    setState(() {
      _role = role;
      _profileComplete = done;
      _loadingProfileState = false;
      _greetingName = (name != null && name.isNotEmpty)
          ? name
          : (mobile != null && mobile.isNotEmpty)
              ? mobile
              : 'there';
    });

    // If logged in but no name yet, fetch profile to populate fullName
    try {
      final auth = context.read<AuthManager?>();
      if (auth != null && auth.isLoggedIn) {
        if (name == null || name.isEmpty) {
          if (role == UserRole.trainer) {
            final id = await auth.getApiTrainerId();
            if (id != null && id.isNotEmpty) {
              await auth.fetchTrainerProfile(id);
            }
          } else {
            await auth.getUserProfile();
          }
          final freshName = await getUserName();
          if (!mounted) return;
          if (freshName != null && freshName.isNotEmpty) {
            setState(() => _greetingName = freshName);
          }
        }
      }
    } catch (_) {}
  }

  void refreshGreeting() => _loadProfileState();

  Future<void> _openProfileFill() async {
    await Navigator.push(
      context,
      MaterialPageRoute(builder: (_) => const ProfileCompletionWizard()),
    );
    await _loadProfileState();
  }

  // ===== Support & SOS (mirror trainer dashboard) =====
  void _openSupport() {
    showDialog(
      context: context,
      builder: (dCtx) => ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: AlertDialog(
            backgroundColor: Colors.white.withOpacity(0.12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: Colors.white.withOpacity(0.3), width: 0.75),
            ),
            title: const Text("Support", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            content: const Text("Need help? Call support or request a callback.", style: TextStyle(color: Colors.white70)),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dCtx), child: const Text("Close", style: TextStyle(color: Colors.white))),
            ],
          ),
        ),
      ),
    );
  }

  void _triggerSOS() {
    showDialog(
      context: context,
      builder: (dCtx) => ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: AlertDialog(
            backgroundColor: Colors.white.withOpacity(0.12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: Colors.white.withOpacity(0.3), width: 0.75),
            ),
            title: const Text("Emergency (SOS)", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            content: const Text("This will alert support. Proceed?", style: TextStyle(color: Colors.white70)),
            actions: [
              TextButton(onPressed: () => Navigator.pop(dCtx), child: const Text("Cancel", style: TextStyle(color: Colors.white))),
              TextButton(
                onPressed: () {
                  Navigator.pop(dCtx);
                  if (mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("SOS triggered.")));
                  }
                },
                child: Text("Confirm", style: TextStyle(color: AppColors.primary, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Future<void> _confirmAndLogout(BuildContext ctx) async {
    final auth = ctx.read<AuthManager?>();
    if (auth == null) return;
    final confirm = await showDialog<bool>(
      context: ctx,
      builder: (dCtx) => ClipRRect(
        borderRadius: BorderRadius.circular(16),
        child: BackdropFilter(
          filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
          child: AlertDialog(
            backgroundColor: Colors.white.withOpacity(0.12),
            shape: RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(16),
              side: BorderSide(color: Colors.white.withOpacity(0.3), width: 0.75),
            ),
            title: const Text("Logout", style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            content: const Text("Are you sure you want to logout?", style: TextStyle(color: Colors.white70)),
            actions: [
              TextButton(
                onPressed: () => Navigator.pop(dCtx, false),
                child: const Text("Cancel", style: TextStyle(color: Colors.white)),
              ),
              TextButton(
                onPressed: () => Navigator.pop(dCtx, true),
                child: const Text("Logout", style: TextStyle(color: Colors.redAccent, fontWeight: FontWeight.w700)),
              ),
            ],
          ),
        ),
      ),
    );
    if (confirm == true) {
      await auth.logout();
      if (!mounted) return;
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const HomeScreen()),
        (route) => false,
      );
    }
  }

  // ===== Notifications (USER) =====
  // Decide which API target to hit for notifications based on role
  Future<Map<String, String>?> _resolveNotificationTarget() async {
    final auth = context.read<AuthManager?>();
    final sp = await SharedPreferences.getInstance();

    if (_role == UserRole.trainer) {
      // Trainer: use canonical DB id for trainer endpoints
      String? trainerId;
      try {
        trainerId = await auth?.getApiTrainerId();
      } catch (_) {
        trainerId = null;
      }
      trainerId ??= sp.getString('fitstreet_trainer_db_id') ?? sp.getString('fitstreet_trainer_id');
      if (trainerId == null || trainerId.isEmpty) return null;
      return {'type': 'trainer', 'id': trainerId};
    }

    // Default to user
    String? userId = auth?.userId;
    userId ??= sp.getString('fitstreet_user_db_id') ?? sp.getString('fitstreet_user_id');
    if (userId == null || userId.isEmpty) return null;
    return {'type': 'user', 'id': userId};
  }

  Future<void> _fetchNotificationsIfLoggedIn() async {
    try {
      final auth = context.read<AuthManager?>();
      if (auth?.isLoggedIn != true) {
        setState(() {
          _notifications = [];
          _notificationCount = 0;
        });
        return;
      }

      final target = await _resolveNotificationTarget();
      if (target == null) {
        setState(() {
          _notifications = [];
          _notificationCount = 0;
        });
        return;
      }

      await _getNotifications(target['type']!, target['id']!);
    } catch (_) {}
  }

  Future<void> _getNotifications(String userType, String id) async {
    setState(() => _loadingNotifications = true);
    try {
      final sp = await SharedPreferences.getInstance();
      final token = sp.getString('fitstreet_token') ?? '';
      final api = FitstreetApi('https://api.fitstreet.in', token: token);

      // GET /api/common/notifications/{userType}/{id}/unread
      final resp = await api.getNotifications(userType, id);
      if (resp.statusCode == 200) {
        dynamic body;
        try {
          body = resp.body.isNotEmpty ? (jsonDecode(resp.body) as Object) : {};
        } catch (_) {
          body = {};
        }
        final map = (body is Map) ? body : {};
        final List raw = (map['notifications'] ?? []) as List;
        final now = DateTime.now();
        final cutoff = now.subtract(const Duration(days: 7));
        bool within7(dynamic n) {
          try {
            final v = n?['createdAt'];
            DateTime? dt;
            if (v is String) {
              dt = DateTime.tryParse(v);
              if (dt == null) {
                final numVal = int.tryParse(v);
                if (numVal != null) {
                  dt = numVal > 100000000000 ? DateTime.fromMillisecondsSinceEpoch(numVal) : DateTime.fromMillisecondsSinceEpoch(numVal * 1000);
                }
              }
            } else if (v is int) {
              dt = v > 100000000000 ? DateTime.fromMillisecondsSinceEpoch(v) : DateTime.fromMillisecondsSinceEpoch(v * 1000);
            }
            if (dt == null) return true; // keep if unknown timestamp
            return dt.isAfter(cutoff);
          } catch (_) {
            return true;
          }
        }
        final filtered = raw.where(within7).toList();
        setState(() {
          _notifications = filtered;
          _notificationCount = filtered.length;
        });
      }
    } catch (_) {
      // ignore for badge
    } finally {
      if (mounted) setState(() => _loadingNotifications = false);
    }
  }

  Future<void> _markNotificationsAsRead(String userType, String id) async {
    try {
      final sp = await SharedPreferences.getInstance();
      final token = sp.getString('fitstreet_token') ?? '';
      final api = FitstreetApi('https://api.fitstreet.in', token: token);

      // PATCH /api/common/notifications/{id}/read/{userType}
      await api.markNotificationsAsRead(id, userType);
      if (mounted) setState(() => _notificationCount = 0);
    } catch (_) {}
  }

  void _toggleNotificationList() async {
    // If already visible, hide it
    if (_notifEntry != null) {
      _hideNotificationOverlay();
      return;
    }

    final target = await _resolveNotificationTarget();
    if (target == null) return;

    _showNotificationOverlay();

  // Mark-as-read; do not refresh on open
    if (_notificationCount > 0) {
      await _markNotificationsAsRead(target['type']!, target['id']!);
      _notifEntry?.markNeedsBuild();
    }
  // Use the currently loaded list to avoid extra refresh
  }

  void _showNotificationOverlay() {
    if (!mounted) return;
    _notifEntry = _createNotifOverlayEntry();
    Overlay.of(context).insert(_notifEntry!);
  }

  void _hideNotificationOverlay() {
    _notifEntry?.remove();
    _notifEntry = null;
  }

  OverlayEntry _createNotifOverlayEntry() {
    return OverlayEntry(
      builder: (ctx) {
        final topPad = MediaQuery.of(ctx).padding.top + kToolbarHeight + 8;
        return Stack(
          children: [
            // Tap outside to dismiss
            Positioned.fill(
              child: GestureDetector(
                behavior: HitTestBehavior.translucent,
                onTap: _hideNotificationOverlay,
                child: const SizedBox.expand(),
              ),
            ),
            Positioned(
              right: 16,
              top: topPad,
              child: Material(
                color: Colors.transparent,
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(16),
                  child: BackdropFilter(
                    filter: ImageFilter.blur(sigmaX: 12, sigmaY: 12),
                    child: Container(
                      width: 320,
                      padding: const EdgeInsets.all(12),
                      decoration: BoxDecoration(
                        gradient: LinearGradient(
                          colors: [
                            Colors.white.withOpacity(0.15),
                            Colors.white.withOpacity(0.05),
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                        borderRadius: BorderRadius.circular(16),
                        border: Border.all(width: 0.75, color: Colors.white.withOpacity(0.3)),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.15),
                            blurRadius: 20,
                            offset: const Offset(0, 8),
                          ),
                        ],
                      ),
                      child: _loadingNotifications
                          ? const Center(
                              child: Padding(
                                padding: EdgeInsets.all(16),
                                child: CircularProgressIndicator(),
                              ),
                            )
                          : (_notifications.isEmpty
                              ? const Text('No notifications', style: TextStyle(color: Colors.white70))
                              : Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  mainAxisSize: MainAxisSize.min,
                                  children: _notifications.map<Widget>((n) {
                                    final msg = (n?['message'] ?? '').toString();
                                    final createdAt = (n?['createdAt'] ?? '').toString();
                                    return Padding(
                                      padding: const EdgeInsets.only(bottom: 8),
                                      child: Column(
                                        crossAxisAlignment: CrossAxisAlignment.start,
                                        children: [
                                          Text(msg, style: const TextStyle(color: Colors.white)),
                                          Text(createdAt, style: const TextStyle(color: Colors.white38, fontSize: 12)),
                                        ],
                                      ),
                                    );
                                  }).toList(),
                                )),
                    ),
                  ),
                ),
              ),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      key: _scaffoldKey,
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        leadingWidth: 90,
        leading: Padding(
          padding: const EdgeInsets.only(left: 12),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Image.asset(
              'assets/image/fitstreet-bull-logo.png',
              fit: BoxFit.contain,
            ),
          ),
        ),
        flexibleSpace: ClipRRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 2, sigmaY: 2),
            child: Container(color: Colors.black.withOpacity(0.15)),
          ),
        ),
        actions: [
          Builder(builder: (ctx) {
            final auth = ctx.watch<AuthManager?>();
            final loggedIn = auth?.isLoggedIn ?? false;

            if (loggedIn) {
              return Row(
                children: [
                  IconButton(
                    icon: const Icon(Icons.account_balance_wallet_outlined),
                    tooltip: "Wallet",
                    onPressed: () {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text("Wallet tapped (coming soon).")),
                      );
                    },
                  ),
                  Stack(
                    children: [
                      IconButton(
                        icon: const Icon(Icons.notifications, color: Colors.white),
                        tooltip: "Notifications",
                        onPressed: _toggleNotificationList,
                      ),
                      if (_notificationCount > 0)
                        Positioned(
                          right: 8,
                          top: 8,
                          child: Container(
                            padding: const EdgeInsets.all(4),
                            decoration: BoxDecoration(
                              color: Colors.red,
                              borderRadius: BorderRadius.circular(10),
                            ),
                            constraints: const BoxConstraints(minWidth: 20, minHeight: 20),
                            child: Text(
                              '$_notificationCount',
                              style: const TextStyle(color: Colors.white, fontSize: 12),
                              textAlign: TextAlign.center,
                            ),
                          ),
                        ),
                    ],
                  ),
                  PopupMenuButton<String>(
                    icon: const Icon(Icons.more_vert, color: Colors.white),
                    onSelected: (value) async {
                      switch (value) {
                        case 'profile':
                          await Navigator.push(
                            context,
                            MaterialPageRoute(builder: (_) => ProfileFillScreen(editableBasics: true)),
                          );
                          await _loadProfileState();
                          break;
                        case 'logout':
                          await _confirmAndLogout(ctx);
                          break;
                      }
                    },
                    itemBuilder: (context) => [
                      const PopupMenuItem(
                        value: 'profile',
                        child: Row(
                          children: [
                            Icon(Icons.person, size: 18),
                            SizedBox(width: 8),
                            Text('Profile'),
                          ],
                        ),
                      ),
                      const PopupMenuItem(
                        value: 'logout',
                        child: Row(
                          children: [
                            Icon(Icons.logout, size: 18),
                            SizedBox(width: 8),
                            Text('Logout'),
                          ],
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(width: 8),
                ],
              );
            } else {
              return Row(
                children: [
                  TextButton(
                    onPressed: () => _openLoginScreen(context),
                    child: const Text(
                      "Login",
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 8),
                  TextButton(
                    onPressed: () => _openLoginScreen(context),
                    child: const Text(
                      "Register",
                      style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                    ),
                  ),
                  const SizedBox(width: 8),
                ],
              );
            }
          }),
        ],
      ),

      // Body in a Stack so the dropdown can be positioned under the AppBar
      body: Stack(
        children: [
          // Background: image + subtle animated liquid gradient overlay
          Container(
            width: double.infinity,
            height: double.infinity,
            decoration: const BoxDecoration(
              image: DecorationImage(
                image: AssetImage('assets/image/bg.png'),
                fit: BoxFit.cover,
                colorFilter: ColorFilter.mode(Colors.black54, BlendMode.darken),
              ),
            ),
            child: Stack(
              children: [
                // Liquid-like animated gradient overlay (below content)
                Positioned.fill(
                  child: IgnorePointer(
                    child: AnimatedBuilder(
                      animation: _liquidCtrl,
                      builder: (context, _) {
                        final t = _liquidCtrl.value * 2 * math.pi;
                        final dx = 0.5 + 0.25 * math.sin(t);
                        final dy = 0.4 + 0.25 * math.cos(t * 1.3);
                        return Container(
                          decoration: BoxDecoration(
                            gradient: RadialGradient(
                              center: Alignment(dx * 2 - 1, dy * 2 - 1),
                              radius: 1.2,
                              colors: [
                                Colors.white.withOpacity(0.06),
                                Colors.white.withOpacity(0.00),
                              ],
                              stops: const [0.0, 1.0],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
                ),
                SafeArea(
                  child: SingleChildScrollView(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        // Auth state for body controls
                        Builder(builder: (ctx) {
                          // This empty builder exists just to establish a local watch context
                          // for auth within the body section below.
                          return const SizedBox.shrink();
                        }),
                        // Greeting
                        Text("Hi $_greetingName 👋", style: Theme.of(context).textTheme.headlineMedium),
                        const SizedBox(height: 4),
                        const Text("Ready for your transformation?", style: TextStyle(color: Colors.white70)),

                        const SizedBox(height: 20),

                        // Complete Profile CTA (only when logged in)
                        if (_loadingProfileState)
                          const SizedBox(height: 8)
                        else if ((context.watch<AuthManager?>()?.isLoggedIn ?? false) && (_role == UserRole.member) && !_profileComplete) ...[
                          GlassCard(
                            onTap: _openProfileFill,
                            child: Container(
                              width: double.infinity,
                              padding: const EdgeInsets.all(12),
                              child: Row(
                                children: [
                                  Container(
                                    width: 56,
                                    height: 56,
                                    decoration: BoxDecoration(
                                      color: Colors.white12,
                                      borderRadius: BorderRadius.circular(12),
                                    ),
                                    child: const Icon(Icons.person_add, color: Colors.white),
                                  ),
                                  const SizedBox(width: 12),
                                  const Expanded(
                                    child: Column(
                                      crossAxisAlignment: CrossAxisAlignment.start,
                                      children: [
                                        Text("Complete your profile",
                                            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
                                        SizedBox(height: 6),
                                        Text("Add weight, height, goals & profile to start booking.",
                                            style: TextStyle(color: Colors.white70, fontSize: 12)),
                                      ],
                                    ),
                                  ),
                                  const Icon(Icons.arrow_forward_ios, color: Colors.white70, size: 18),
                                ],
                              ),
                            ),
                          ),
                          const SizedBox(height: 12),
                        ],

                        // Quick Actions
                        GridView.count(
                          shrinkWrap: true,
                          crossAxisCount: 2,
                          crossAxisSpacing: 16,
                          mainAxisSpacing: 16,
                          childAspectRatio: 1.1,
                          physics: const NeverScrollableScrollPhysics(),
                          children: [
                            GlassCard(
                              onTap: () {
                                // Allow browsing trainers without login or profile completion
                                Navigator.push(context, MaterialPageRoute(builder: (_) => const TrainerListScreen()));
                              },
                              child: _quickAction(Icons.fitness_center, "Trainers"),
                            ),
                            GlassCard(
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const BookingScreen())),
                              child: _quickAction(Icons.calendar_today, "Bookings"),
                            ),
                            GlassCard(
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DietScreen())),
                              child: _quickAction(Icons.restaurant_menu, "Diet Plans"),
                            ),
                            GlassCard(
                              onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const CounsellorScreen())),
                              child: _quickAction(Icons.psychology, "Counsellors"),
                            ),
                          ],
                        ),

                        const SizedBox(height: 32),

                        // Featured Trainers
                        Text("🔥 Featured Trainers", style: Theme.of(context).textTheme.headlineMedium),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 200,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              _trainerCard(context, "Rahul Sharma", "Yoga", "₹500"),
                              _trainerCard(context, "Sneha Kapoor", "Strength", "₹700"),
                              _trainerCard(context, "Amit Singh", "Zumba", "₹600"),
                            ],
                          ),
                        ),

                        const SizedBox(height: 32),

                        // Popular Diet Plans
                        Text("🥗 Popular Diet Plans", style: Theme.of(context).textTheme.headlineMedium),
                        const SizedBox(height: 12),
                        SizedBox(
                          height: 160,
                          child: ListView(
                            scrollDirection: Axis.horizontal,
                            children: [
                              _dietCard(context, "Organic Protein Pack", "₹999"),
                              _dietCard(context, "Weight Loss Plan", "₹1499"),
                              _dietCard(context, "Superfood Combo", "₹799"),
                            ],
                          ),
                        ),

                        const SizedBox(height: 32),

                        // Special Offers
                        Text("⚡ Special Offers", style: Theme.of(context).textTheme.headlineMedium),
                        const SizedBox(height: 12),
                        GlassCard(
                          onTap: () {
                            ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text("Offer applied!")));
                          },
                          child: Container(
                            width: double.infinity,
                            padding: const EdgeInsets.all(20),
                            child: const Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                Text("20% OFF on First Booking 🎉",
                                    style: TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.bold)),
                                SizedBox(height: 6),
                                Text("Book your first session now and save big!", style: TextStyle(color: Colors.white70)),
                              ],
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
              ],
            ),
          ),

          // Notification dropdown now rendered via OverlayEntry above the AppBar

          // Floating actions (Support & SOS)
          Positioned(
            left: 18,
            bottom: 18,
            child: FloatingActionButton(
              heroTag: 'home_support_fab',
              onPressed: _openSupport,
              backgroundColor: AppColors.secondary,
              child: const Icon(Icons.headset_mic, color: Colors.white),
            ),
          ),
          Positioned(
            right: 18,
            bottom: 18,
            child: FloatingActionButton(
              heroTag: 'home_sos_fab',
              onPressed: _triggerSOS,
              backgroundColor: AppColors.primary,
              child: const Icon(Icons.sos, color: Colors.white),
            ),
          ),
        ],
      ),
    );
  }

  // ===== Helpers =====

  void _openLoginScreen(BuildContext context) {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const LoginScreenStyled()));
  }

  Widget _quickAction(IconData icon, String label) {
    return Column(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(icon, size: 40, color: Colors.white),
        const SizedBox(height: 10),
        Text(label, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 16)),
      ],
    );
  }

  Widget _trainerCard(BuildContext context, String name, String speciality, String price) {
    final trainer = {"name": name, "speciality": speciality, "price": price};
    return Padding(
      padding: const EdgeInsets.only(right: 16),
      child: GlassCard(
        onTap: () {
          Navigator.push(context, MaterialPageRoute(builder: (_) => TrainerProfileScreen(trainer: trainer)));
        },
        child: Container(
          width: 160,
          padding: const EdgeInsets.all(12),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Expanded(
              child: Container(
                decoration: BoxDecoration(
                  borderRadius: BorderRadius.circular(12),
                  color: Colors.white24,
                ),
                child: const Center(child: Icon(Icons.person, size: 50, color: Colors.white70)),
              ),
            ),
            const SizedBox(height: 8),
            Text(name, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold)),
            Text("$speciality · $price", style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ]),
        ),
      ),
    );
  }

  Widget _dietCard(BuildContext context, String name, String price) {
    return Padding(
      padding: const EdgeInsets.only(right: 16),
      child: GlassCard(
        onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => const DietScreen())),
        child: Container(
          width: 160,
          height: 140,
          padding: const EdgeInsets.all(12),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              const Icon(Icons.restaurant, color: Colors.white, size: 32),
              const SizedBox(height: 8),
              Flexible(
                child: Text(
                  name,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: const TextStyle(
                    color: Colors.white,
                    fontWeight: FontWeight.w600,
                    fontSize: 14,
                  ),
                ),
              ),
              const SizedBox(height: 4),
              Text(
                price,
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                  color: Colors.white70,
                  fontWeight: FontWeight.bold,
                  fontSize: 13,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
