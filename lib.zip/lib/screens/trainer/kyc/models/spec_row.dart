import 'package:flutter/material.dart';

class SpecRow {
  String? specialization;
  final TextEditingController certificateName = TextEditingController();
  String? certificatePhotoPath;
}
