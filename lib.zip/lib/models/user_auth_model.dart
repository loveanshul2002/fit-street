// lib/models/user_auth_model.dart
enum AuthMode {
  login,
  signup,
}