// lib/screens/trainer/kyc/trainer_kyc_wizard.dart
import 'dart:typed_data';
import 'dart:io';
import 'dart:convert';
import 'dart:ui' show ImageFilter;
import 'package:flutter/material.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:image_picker/image_picker.dart';
import 'package:http/http.dart' as http;
import 'package:provider/provider.dart';

// import '../../../config/app_colors.dart';
import '../../../widgets/glass_card.dart';
import 'steps/identity_step.dart';
import 'steps/bank_step.dart';
import 'steps/payment_step.dart';
import 'steps/professional_step.dart';
import 'steps/consent_step.dart';
import 'models/spec_row.dart';
import '../../../state/auth_manager.dart';
import '../../../services/fitstreet_api.dart';

class TrainerKycWizard extends StatefulWidget {
  const TrainerKycWizard({super.key});

  @override
  State<TrainerKycWizard> createState() => _TrainerKycWizardState();
}

class _TrainerKycWizardState extends State<TrainerKycWizard> {
  final PageController _page = PageController();
  int _step = 0;

  // Form keys
  final GlobalKey<FormState> fIdentity = GlobalKey<FormState>();
  final GlobalKey<FormState> fBank = GlobalKey<FormState>();
  final GlobalKey<FormState> fProfessional = GlobalKey<FormState>();

  // ---------- Shared state ----------
  String? language;
  final TextEditingController fullName = TextEditingController();
  final TextEditingController dob = TextEditingController();
  final ValueNotifier<String?> gender = ValueNotifier(null);

  final TextEditingController mobile = TextEditingController();
  final TextEditingController email = TextEditingController();
  final TextEditingController bioData = TextEditingController();

  final TextEditingController pincode = TextEditingController();
  final TextEditingController city = TextEditingController();
  final TextEditingController stateCtrl = TextEditingController();

  final TextEditingController currentPincode = TextEditingController();
  final TextEditingController currentCity = TextEditingController();
  final TextEditingController currentState = TextEditingController();
  bool sameAsPermanent = true;
  final TextEditingController addrPermanent = TextEditingController();
  final TextEditingController addrCurrent = TextEditingController();

  final TextEditingController emgName = TextEditingController();
  final TextEditingController emgRelation = TextEditingController();
  final TextEditingController emgMobile = TextEditingController();

  final TextEditingController aadhaar = TextEditingController();

  // ✅ Added paths here
  String? selfiePath,  aadhaarPhotofrontPath, aadhaarPhotobackPath;

  // ---------- Bank ----------
  final TextEditingController accName = TextEditingController();
  final TextEditingController ifsc = TextEditingController();
  final TextEditingController bankName = TextEditingController();
  final TextEditingController branch = TextEditingController();
  final TextEditingController upi = TextEditingController();

  // ---------- Professional ----------
  String? experience;
  final Set<String> trainingLangs = {};
  final TextEditingController otherLangCtrl = TextEditingController();

  // **Parent-owned professional rows**
  final List<SpecRow> professionalRows = [SpecRow()];
  // Track existing proof ids from server
  final Set<String> _loadedProofIds = {};

  // NEW: pricing fields (kept as strings that will be sent to backend)
  String? oneSessionPrice;
  String? monthlySessionPrice;

  // ---------- Consent ----------
  bool noCriminalRecord = false;
  bool agreeHnS = false;
  bool ackTrainerAgreement = false;
  bool ackCancellationPolicy = false;
  bool isPaid = false;


  final TextEditingController esignName = TextEditingController();
  final TextEditingController esignDate = TextEditingController();

  // signature bytes (set by consent step)
  Uint8List? signaturePng;
  String? paymentScreenshotPath;

  // Uploading flag
  bool _uploading = false;
  bool _savingPartial = false; // flag for step-wise save

  final ImagePicker _picker = ImagePicker();

  @override
  void initState() {
    super.initState();
    final now = DateTime.now();
    esignDate.text =
    "${now.day.toString().padLeft(2, '0')}/${now.month.toString().padLeft(
        2, '0')}/${now.year}";
    if (professionalRows.isEmpty) professionalRows.add(SpecRow());
    _loadSavedProfile();
  }

  // Fetch specialization proofs and populate professionalRows. Optionally pass embedded map from getTrainer.
  Future<void> _prefillSpecializationsFromServer(String trainerId, {Map? embedded}) async {
    try {
      _loadedProofIds.clear();
      List<dynamic>? list;

      // Prefer dedicated endpoint
      try {
        final api = await _api();
        final resp = await api.getSpecializationProofs(trainerId);
        dynamic body;
        try { body = jsonDecode(resp.body); } catch (_) { body = null; }
        if (body is Map) {
          final data = body['data'] ?? body['proofs'] ?? body['items'] ?? body['list'];
          if (data is List) list = data;
        } else if (body is List) {
          list = body;
        }
      } catch (e) {
        debugPrint('getSpecializationProofs failed: $e');
      }

      // Fallback to embedded
    if (list == null || list.isEmpty) {
        try {
      final proofs = (embedded != null && embedded['specializationProofs'] is List)
        ? embedded['specializationProofs'] as List
        : (embedded != null && embedded['specializations'] is List)
          ? embedded['specializations'] as List
                  : null;
          if (proofs != null) list = proofs;
        } catch (_) {}
      }

    if (list == null || list.isEmpty) return;

      // dispose existing controllers
      for (final r in professionalRows) {
        try { r.certificateName.dispose(); } catch (_) {}
      }
      professionalRows.clear();

  for (final item in list) {
        if (item is! Map) continue;
        final spec = (item['specialization'] ?? item['spec'] ?? '').toString();
        if (spec.isEmpty) continue;
        final name = (item['certificateName'] ?? '').toString();
        final photo = (item['certificateImageURL'] ?? item['photoURL'] ?? '').toString();
        final pid = (item['_id'] ?? item['id'])?.toString();

        final row = SpecRow();
        row.specialization = spec;
        if (name.isNotEmpty) row.certificateName.text = name;
        if (photo.isNotEmpty) row.certificatePhotoPath = photo;
        if (pid != null && pid.isNotEmpty) {
          row.proofId = pid;
          _loadedProofIds.add(pid);
        }
        professionalRows.add(row);
      }

      if (professionalRows.isEmpty) professionalRows.add(SpecRow());
    } catch (e) {
      debugPrint('Prefill specializations failed: $e');
    }
  }

  Future<void> _loadSavedProfile() async {
    final sp = await SharedPreferences.getInstance();
    fullName.text = sp.getString('fitstreet_trainer_name') ?? '';
    mobile.text = sp.getString('fitstreet_trainer_mobile') ??
        sp.getString('fitstreet_user_mobile') ??
        '';
    email.text = sp.getString('fitstreet_trainer_email') ?? '';
  bioData.text = sp.getString('fitstreet_trainer_bio') ?? '';
  

    try {
      if (!mounted) return; // guard context usage across async gap
      final auth = context.read<AuthManager>();
      final id = await auth.getApiTrainerId();
      if (id != null && id.isNotEmpty) {
        final res = await auth.fetchTrainerProfile(id);
        if (!mounted) return;
        if (res['success'] == true && res['body'] is Map) {
          final data = res['body']['data'] ?? res['body'];
          if (data['fullName'] != null) fullName.text = data['fullName'];
          if (data['mobileNumber'] != null) mobile.text = data['mobileNumber'];
          if (data['email'] != null) email.text = data['email'];
          if (data['gender'] != null) gender.value = data['gender'];
          if (data['bioData'] != null) bioData.text = data['bioData'];

          // DOB -> UI format DD/MM/YYYY if possible
          final dobRaw = data['dob'];
          if (dobRaw is String && dobRaw.isNotEmpty) {
            try {
              // Handle YYYY-MM-DD or ISO
              DateTime? parsed;
              if (RegExp(r'^\d{4}-\d{2}-\d{2}').hasMatch(dobRaw)) {
                parsed = DateTime.tryParse(dobRaw);
              } else if (RegExp(r'^\d{2}/\d{2}/\d{4}$').hasMatch(dobRaw)) {
                // already in UI format
                parsed = null;
                dob.text = dobRaw;
              }
              if (parsed != null) {
                dob.text = '${parsed.day.toString().padLeft(2, '0')}/${parsed.month.toString().padLeft(2, '0')}/${parsed.year}';
              }
            } catch (_) {}
          }

          // Address (permanent)
          if (data['pincode'] != null) pincode.text = (data['pincode'] ?? '').toString();
          if (data['city'] != null && data['city'].toString().isNotEmpty) city.text = data['city'];
          if (data['state'] != null && data['state'].toString().isNotEmpty) stateCtrl.text = data['state'];
          if (data['address'] != null && data['address'].toString().isNotEmpty) addrPermanent.text = data['address'];

          // Address (current) and parity
          final same = (data['isAddressSame'] == true) || (data['isAddressSame']?.toString() == 'true');
          sameAsPermanent = same;
          final currentPin = (data['currentPincode'] ?? '').toString();
          final currentCityVal = (data['currentCity'] ?? '').toString();
          final currentStateVal = (data['currentState'] ?? '').toString();
          final currentAddr = (data['currentAddress'] ?? '').toString();
          if (!same) {
            if (currentPin.isNotEmpty) currentPincode.text = currentPin;
            if (currentCityVal.isNotEmpty) currentCity.text = currentCityVal;
            if (currentStateVal.isNotEmpty) currentState.text = currentStateVal;
            if (currentAddr.isNotEmpty) addrCurrent.text = currentAddr;
          } else {
            // mirror permanent
            currentPincode.text = pincode.text;
            currentCity.text = city.text;
            currentState.text = stateCtrl.text;
            addrCurrent.text = addrPermanent.text;
          }

          // Emergency details
          if (data['emergencyPersonName'] != null) emgName.text = data['emergencyPersonName'];
          if (data['emergencyPersonMobile'] != null) emgMobile.text = data['emergencyPersonMobile'];
          if (data['emergencyPersonRelation'] != null) emgRelation.text = data['emergencyPersonRelation'];

          // IDs and photos
          if (data['aadhaarCard'] != null) aadhaar.text = data['aadhaarCard'].toString();
          // Support remote image URLs as paths to preview in steps
          if (data['trainerImageURL'] != null && data['trainerImageURL'].toString().isNotEmpty) {
            selfiePath = data['trainerImageURL'].toString();
          }
          if (data['aadhaarFrontImageURL'] != null && data['aadhaarFrontImageURL'].toString().isNotEmpty) {
            aadhaarPhotofrontPath = data['aadhaarFrontImageURL'].toString();
          }
          if (data['aadhaarBackImageURL'] != null && data['aadhaarBackImageURL'].toString().isNotEmpty) {
            aadhaarPhotobackPath = data['aadhaarBackImageURL'].toString();
          }

          // Bank details
          if (data['accountNumber'] != null) accName.text = data['accountNumber'].toString();
          if (data['ifscCode'] != null) ifsc.text = data['ifscCode'].toString();
          if (data['bankName'] != null) bankName.text = data['bankName'].toString();
          if (data['branch'] != null) branch.text = data['branch'].toString();
          if (data['upiId'] != null) upi.text = data['upiId'].toString();

          // Experience
          if (data['experience'] != null) experience = data['experience'].toString();

          // Languages: CSV -> trainingLangs + otherLangCtrl
          if (data['languages'] != null && data['languages'].toString().isNotEmpty) {
            final raw = data['languages'].toString();
            final tokens = raw.split(RegExp(r'[,;]')).map((e) => e.trim()).where((e) => e.isNotEmpty).toList();
            final known = <String>{'English','Hindi'};
            final others = <String>[];
            trainingLangs.clear();
            for (final t in tokens) {
              if (known.contains(t)) {
                trainingLangs.add(t);
              } else {
                others.add(t);
              }
            }
            if (others.isNotEmpty) {
              trainingLangs.add('Other');
              otherLangCtrl.text = others.join(', ');
            } else {
              otherLangCtrl.clear();
            }
          }

          // If backend returns pricing, prefill them
          if (data['oneSessionPrice'] != null) {
            oneSessionPrice = data['oneSessionPrice'].toString();
          }
          if (data['monthlySessionPrice'] != null) {
            monthlySessionPrice = data['monthlySessionPrice'].toString();
          }
          if (data['isPaid'] == true || (data['isPaid']?.toString() == 'true')) {
            isPaid = true;
          }


          // Prefill specialization proofs using dedicated endpoint; fallback to embedded
          await _prefillSpecializationsFromServer(id, embedded: data);
        }
      }
      // Reflect all loaded values in UI-dependent widgets like PaymentStep
      if (mounted) setState(() {});
    } catch (e) {
      debugPrint('loadSavedProfile failed: $e');
    }
  }

  @override
  void dispose() {
    _page.dispose();
    fullName.dispose();
    dob.dispose();
    gender.dispose();
    mobile.dispose();
    email.dispose();
  bioData.dispose();
    pincode.dispose();
    city.dispose();
    stateCtrl.dispose();
    currentPincode.dispose();
    currentCity.dispose();
    currentState.dispose();
    addrPermanent.dispose();
    addrCurrent.dispose();
    emgName.dispose();
    emgRelation.dispose();
    emgMobile.dispose();
    aadhaar.dispose();
    accName.dispose();
    ifsc.dispose();
    bankName.dispose();
    branch.dispose();
    upi.dispose();
    otherLangCtrl.dispose();
    esignName.dispose();
    esignDate.dispose();
    for (final r in professionalRows) {
      r.certificateName.dispose();
    }
    super.dispose();
  }

  void _toast(String msg) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
  }

  // ignore: unused_element
  Future<String?> _captureSelfie() async {
    try {
      final XFile? picked = await _picker.pickImage(
        source: ImageSource.camera,
        preferredCameraDevice: CameraDevice.front,
        maxWidth: 1600,
        maxHeight: 1600,
        imageQuality: 80,
      );
      if (picked == null) return null;

      final tmpDir = await getTemporaryDirectory();
      final fileName =
          'selfie_${DateTime
          .now()
          .millisecondsSinceEpoch}${p.extension(picked.path)}';
      final saved = File('${tmpDir.path}/$fileName');
      final bytes = await picked.readAsBytes();
      await saved.writeAsBytes(bytes);

      return saved.path;
    } catch (e, st) {
      debugPrint('captureSelfie error: $e\n$st');
      return null;
    }
  }

  Future<void> _next() async {
    if (_step == 0) { // Identity
      if (fIdentity.currentState!.validate() && IdentityStep.validateAge(dob, _toast)) {
        // Mandatory document checks before leaving Identity step
        if (selfiePath == null || selfiePath!.isEmpty) {
          _toast('Please upload your Selfie.');
          return;
        }
        if (aadhaarPhotofrontPath == null || aadhaarPhotofrontPath!.isEmpty) {
          _toast('Please upload Aadhaar front image.');
          return;
        }
        if (aadhaarPhotobackPath == null || aadhaarPhotobackPath!.isEmpty) {
          _toast('Please upload Aadhaar back image.');
          return;
        }
        final ok = await _saveStepIdentity();
        if (ok) { setState(() => _step = 1); _page.jumpToPage(1); }
      }
      return;
    }
    if (_step == 1) { // Payment step just moves forward when paid
      if (!isPaid) { _toast('Please complete activation payment.'); return; }
      setState(() => _step = 2); _page.jumpToPage(2); return;
    }
    if (_step == 2) { // Bank
      if (fBank.currentState!.validate()) {
        final ok = await _saveStepBank();
        if (ok) { setState(() => _step = 3); _page.jumpToPage(3); }
      }
      return;
    }
    if (_step == 3) { // Professional
      if (fProfessional.currentState!.validate() && ProfessionalStep.validateProfessionalRows(professionalRows, _toast)) {
        final ok = await _saveStepProfessional();
        if (ok) { setState(() => _step = 4); _page.jumpToPage(4); }
      }
      return;
    }
    if (_step == 4) { // Consent
      // First: check required uploads
      if (selfiePath == null ||
          selfiePath!.isEmpty ||
          aadhaarPhotofrontPath == null ||
          aadhaarPhotofrontPath!.isEmpty ||
          aadhaarPhotobackPath == null ||
          aadhaarPhotobackPath!.isEmpty) {
        _toast("Please upload Selfie, Aadhaar front and back.");
        return;
      }

      // Then: check consent
      final consentOk = ConsentStep.validateConsent(
        signaturePng: signaturePng,
        fullName: fullName.text,
        esignName: esignName.text,
        esignDate: esignDate.text,
        noCriminalRecord: noCriminalRecord,
        agreeHnS: agreeHnS,
        ackTrainerAgreement: ackTrainerAgreement,
        ackCancellationPolicy: ackCancellationPolicy,
  isPaid: isPaid,
        toast: _toast,
      );

      if (consentOk) {
        if (!mounted) return;
        // Perform upload; check mounted again after async gap before using context
        final ok = await _uploadKyc();
        if (!ok) return;
        if (!mounted) return;
        _toast("KYC submitted! Well verify it shortly.");
        Navigator.pop(context, true);
      }

      return;
    }
  }

  void _back() {
  // Back navigation for 5-step flow
  if (_step == 4) { setState(() => _step = 3); _page.jumpToPage(3); return; }
  if (_step == 3) { setState(() => _step = 2); _page.jumpToPage(2); return; }
  if (_step == 2) { setState(() => _step = 1); _page.jumpToPage(1); return; }
  if (_step == 1) { setState(() => _step = 0); _page.jumpToPage(0); return; }
  Navigator.pop(context); // step 0 exit
  }

  @override
  Widget build(BuildContext context) {
  final bool keyboardOpen = MediaQuery.of(context).viewInsets.bottom > 0.0;
    return Scaffold(
      extendBodyBehindAppBar: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        elevation: 0,
        automaticallyImplyLeading: false,
        leadingWidth: 120,
        leading: Row(
          children: [
            const SizedBox(width: 8),
            IconButton(
              icon: const Icon(Icons.arrow_back_ios_new_rounded, color: Colors.white),
              onPressed: _back,
              tooltip: 'Back',
            ),
            const SizedBox(width: 4),
            Image.asset(
              'assets/image/fitstreet-bull-logo.png',
              height: 36,
              fit: BoxFit.contain,
            ),
          ],
        ),
        title: const Text(
          "Trainer KYC",
          style: TextStyle(color: Colors.white, fontWeight: FontWeight.w700),
        ),
        centerTitle: true,
        flexibleSpace: ClipRect(
          child: BackdropFilter(
            filter: ImageFilter.blur(sigmaX: 2, sigmaY: 2),
            child: Container(color: Color.fromARGB((0.15 * 255).round(), 0, 0, 0)),
          ),
        ),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          Image.asset('assets/image/bg.png', fit: BoxFit.cover),
          Container(color: Color.fromARGB((0.35 * 255).round(), 0, 0, 0)),
          SafeArea(
            child: Column(
              children: [
                if (!keyboardOpen)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 12, 16, 0),
                    child: GlassCard(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: Row(
                          children: [
                            _stepPill(0, "Identity"),
                            const SizedBox(width: 8),
                            _stepPill(1, "Payment"),
                            const SizedBox(width: 8),
                            _stepPill(2, "Bank"),
                            const SizedBox(width: 8),
                            _stepPill(3, "Professional"),
                            const SizedBox(width: 8),
                            _stepPill(4, "Consent"),
                          ],
                        ),
                      ),
                    ),
                  ),
                const SizedBox(height: 8),
                Expanded(
                  child: PageView(
                    controller: _page,
                    physics: const NeverScrollableScrollPhysics(),
                    children: [
                      IdentityStep(
                        formKey: fIdentity,
                        language: language,
                        onLanguageChanged: (v) => setState(() => language = v),
                        fullName: fullName,
                        dob: dob,
                        gender: gender,
                        mobile: mobile,
                        email: email,
                        bioData: bioData,
                        pincode: pincode,
                        city: city,
                        stateCtrl: stateCtrl,
                        currentPincode: currentPincode,
                        currentCity: currentCity,
                        currentState: currentState,
                        sameAsPermanent: sameAsPermanent,
                        onSameAsPermanentChanged: (v) => setState(() {
                          sameAsPermanent = v;
                          if (v) {
                            addrCurrent.text = addrPermanent.text;
                            currentPincode.text = pincode.text;
                            currentCity.text = city.text;
                            currentState.text = stateCtrl.text;
                          } else {
                            addrCurrent.clear();
                            currentPincode.clear();
                            currentCity.clear();
                            currentState.clear();
                          }
                        }),
                        addrPermanent: addrPermanent,
                        addrCurrent: addrCurrent,
                        emgName: emgName,
                        emgRelation: emgRelation,
                        emgMobile: emgMobile,
                        aadhaar: aadhaar,
                        aadhaarPhotofrontPath: aadhaarPhotofrontPath,
                        aadhaarPhotobackPath: aadhaarPhotobackPath,
                        selfiePath: selfiePath,
                        pickAadhaarPhotofront: (p) => setState(() => aadhaarPhotofrontPath = p),
                        pickAadhaarPhotoback: (p) => setState(() => aadhaarPhotobackPath = p),
                        pickSelfie: (p) => setState(() => selfiePath = p),
                        onPincodeChanged: _onPincodeChanged,
                        onCurrentPincodeChanged: _onCurrentPincodeChanged,
                        readOnlyFullName: true,
                        readOnlyMobile: true,
                      ),
                      PaymentStep(
                        isPaid: isPaid,
                        onPaidChanged: (v) async {if (!mounted) return; setState(() => isPaid = v);
                          if (v) {
                            try { final trainerId = await _getTrainerId(); if (trainerId != null && trainerId.isNotEmpty) { final api = await _api(); await api.updateTrainerProfileMultipart(trainerId, fields: {'isPaid': 'true'}); } } catch (e) { debugPrint('mark isPaid failed: $e'); }
                          }
                        },
                        fullName: fullName.text,
                        mobile: mobile.text,
                        email: email.text,
                      ),
                      BankStep(
                        formKey: fBank,
                        accName: accName,
                        ifsc: ifsc,
                        bankName: bankName,
                        branch: branch,
                        upi: upi,
                      ),
                      ProfessionalStep(
                        formKey: fProfessional,
                        experience: experience,
                        onExperienceChanged: (v) => setState(() => experience = v),
                        trainingLangs: trainingLangs,
                        otherLangCtrl: otherLangCtrl,
                        rows: professionalRows,
                        onOneSessionPriceChanged: (v) => setState(() => oneSessionPrice = v),
                        onMonthlySessionPriceChanged: (v) => setState(() => monthlySessionPrice = v),
                        oneSessionPriceInitial: oneSessionPrice,
                        monthlySessionPriceInitial: monthlySessionPrice,
                      ),
                      ConsentStep(
                        noCriminalRecord: noCriminalRecord,
                        agreeHnS: agreeHnS,
                        ackTrainerAgreement: ackTrainerAgreement,
                        ackCancellationPolicy: ackCancellationPolicy,
                        onChange: ({
                          bool? noCrime,
                          bool? hns,
                          bool? agr,
                          bool? cancel,
                          bool? payout,
                          bool? privacy,
                        }) {
                          setState(() {
                            if (noCrime != null) noCriminalRecord = noCrime;
                            if (hns != null) agreeHnS = hns;
                            if (agr != null) ackTrainerAgreement = agr;
                            if (cancel != null) ackCancellationPolicy = cancel;
                          });
                        },
                        esignName: esignName,
                        esignDate: esignDate,
                        onSignatureBytes: (bytes) => signaturePng = bytes,
                        isPaid: isPaid,
                      ),
                    ],
                  ),
                ),
                if (!keyboardOpen)
                  Padding(
                    padding: const EdgeInsets.fromLTRB(16, 0, 16, 16),
                    child: Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white,
                              side: BorderSide(color: Color.fromARGB((0.6 * 255).round(), 255, 255, 255)),
                            ),
                            onPressed: _back,
                            child: Text(_step == 0 ? "Exit" : "Back"),
                          ),
                        ),
                        const SizedBox(width: 12),
                        Expanded(
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: Color.fromARGB((0.2 * 255).round(), 255, 255, 255),
                            ),
                            onPressed: _next,
                            child: Text(
                              _step < 4 ? "Continue" : "Submit KYC",
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  Widget _stepPill(int i, String label) {
    final active = i == _step;
    return Expanded(
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
      color: active
        ? Color.fromARGB((0.25 * 255).round(), 255, 255, 255)
        : Color.fromARGB((0.12 * 255).round(), 255, 255, 255),
          borderRadius: BorderRadius.circular(12),
      border: Border.all(color: Color.fromARGB((0.25 * 255).round(), 255, 255, 255)),
        ),
        alignment: Alignment.center,
        child: Text(label,
            style: TextStyle(
              color: Colors.white,
              fontWeight: active ? FontWeight.w700 : FontWeight.w500,
            )),
      ),
    );
  }

  void _onPincodeChanged(String v) {
    if (v.length == 6 && RegExp(r'^\d{6}$').hasMatch(v)) {
      () async {
        try {
          final auth = context.read<AuthManager>();
          final d = await auth.getCityState(v);
          if (!mounted) return;
          setState(() {
            city.text = (d != null && (d['city'] ?? '').isNotEmpty) ? d['city']! : '—';
            stateCtrl.text = (d != null && (d['state'] ?? '').isNotEmpty) ? d['state']! : '—';
            if (sameAsPermanent) {
              addrCurrent.text = addrPermanent.text;
              currentPincode.text = pincode.text;
              currentCity.text = city.text;
              currentState.text = stateCtrl.text;
            }
          });
        } catch (_) {
          if (!mounted) return;
          setState(() {
            city.text = '—';
            stateCtrl.text = '—';
            if (sameAsPermanent) {
              currentCity.text = '—';
              currentState.text = '—';
              currentPincode.text = pincode.text;
            }
          });
        }
      }();
    } else {
      setState(() {
        city.clear();
        stateCtrl.clear();
        if (sameAsPermanent) {
          currentCity.clear();
          currentState.clear();
          currentPincode.text = pincode.text;
        }
      });
    }
  }

  void _onCurrentPincodeChanged(String v) {
    if (v.length == 6 && RegExp(r'^\d{6}$').hasMatch(v)) {
      () async {
        try {
          final auth = context.read<AuthManager>();
          final d = await auth.getCityState(v);
          if (!mounted) return;
          setState(() {
            currentCity.text = (d != null && (d['city'] ?? '').isNotEmpty) ? d['city']! : '—';
            currentState.text = (d != null && (d['state'] ?? '').isNotEmpty) ? d['state']! : '—';
          });
        } catch (_) {
          if (!mounted) return;
          setState(() {
            currentCity.text = '—';
            currentState.text = '—';
          });
        }
      }();
    } else {
      setState(() {
        currentCity.clear();
        currentState.clear();
      });
    }
  }


  // removed mock pincode lookup; now using AuthManager.getCityState

  /// _uploadKyc
  /// - collects fields and files
  /// - calls FitstreetApi.updateTrainerProfileMultipart(trainerId, ...)
  /// - then uploads specialization proofs individually via createSpecializationProof()
  Future<bool> _uploadKyc() async {
    if (_uploading) return false;
    setState(() => _uploading = true);

    try {
      final auth = context.read<AuthManager>();
      String? trainerId;
      try {
        trainerId = await auth.getApiTrainerId();
      } catch (_) {
        trainerId = null;
      }

      final sp = await SharedPreferences.getInstance();
      trainerId ??= sp.getString('fitstreet_trainer_db_id') ??
          sp.getString('fitstreet_trainer_id');

      if (trainerId == null || trainerId.isEmpty) {
        _toast("Trainer id not found. Complete signup (OTP) first.");
        return false;
      }

      // Convert DOB from DD/MM/YYYY to YYYY-MM-DD (if possible)
      String? dobIso;
      try {
        final txt = dob.text.trim();
        if (txt.isNotEmpty && RegExp(r'^\d{2}/\d{2}/\d{4}$').hasMatch(txt)) {
          final parts = txt.split('/');
          dobIso =
          "${parts[2]}-${parts[1].padLeft(2, '0')}-${parts[0].padLeft(2, '0')}";
        } else if (txt.isNotEmpty) {
          dobIso = txt;
        }
      } catch (_) {
        dobIso = dob.text.trim();
      }

      // Combine languages: selected chips + typed "Other" value(s)
      final List<String> langs = trainingLangs
          .where((l) => l.toLowerCase() != 'other')
          .map((s) => s.trim())
          .where((s) => s.isNotEmpty)
          .toList();
      if (trainingLangs.any((l) => l.toLowerCase() == 'other') &&
          otherLangCtrl.text
              .trim()
              .isNotEmpty) {
        // support comma/semicolon separated additional other languages
        langs.addAll(otherLangCtrl.text
            .split(RegExp(r'[,;]'))
            .map((s) => s.trim())
            .where((s) => s.isNotEmpty));
      }

      // Build fields exactly as backend expects
      final Map<String, String> fields = {
        if (fullName.text
            .trim()
            .isNotEmpty) 'fullName': fullName.text.trim(),
        if (mobile.text
            .trim()
            .isNotEmpty) 'mobileNumber': mobile.text.trim(),
  if (bioData.text.trim().isNotEmpty) 'bioData': bioData.text.trim(),
        if (dobIso != null && dobIso.isNotEmpty) 'dob': dobIso,
        if (email.text
            .trim()
            .isNotEmpty) 'email': email.text.trim(),
        if (pincode.text
            .trim()
            .isNotEmpty) 'pincode': pincode.text.trim(),
        if (city.text.trim().isNotEmpty && city.text.trim() != '—') 'city': city.text.trim(),
        if (stateCtrl.text.trim().isNotEmpty && stateCtrl.text.trim() != '—') 'state': stateCtrl.text.trim(),

    // indicate whether current = permanent (parity with user profile form)
    'isAddressSame': sameAsPermanent ? 'true' : 'false',

        // current address pincode/city/state when different from permanent
  if (!sameAsPermanent && currentPincode.text.trim().isNotEmpty) 'currentPincode': currentPincode.text.trim(),
  if (!sameAsPermanent && currentCity.text.trim().isNotEmpty && currentCity.text.trim() != '—') 'currentCity': currentCity.text.trim(),
  if (!sameAsPermanent && currentState.text.trim().isNotEmpty && currentState.text.trim() != '—') 'currentState': currentState.text.trim(),
    // when same, mirror permanent into current*
    if (sameAsPermanent && pincode.text
      .trim()
      .isNotEmpty) 'currentPincode': pincode.text.trim(),
  if (sameAsPermanent && city.text.trim().isNotEmpty && city.text.trim() != '—') 'currentCity': city.text.trim(),
  if (sameAsPermanent && stateCtrl.text.trim().isNotEmpty && stateCtrl.text.trim() != '—') 'currentState': stateCtrl.text.trim(),

        if (addrPermanent.text
            .trim()
            .isNotEmpty) 'address': addrPermanent.text.trim(),
    if (!sameAsPermanent && addrCurrent.text
      .trim()
      .isNotEmpty) 'currentAddress': addrCurrent.text.trim(),
    if (sameAsPermanent && addrPermanent.text
      .trim()
      .isNotEmpty) 'currentAddress': addrPermanent.text.trim(),
        if (emgName.text
            .trim()
            .isNotEmpty) 'emergencyPersonName': emgName.text.trim(),
        if (emgMobile.text
            .trim()
            .isNotEmpty) 'emergencyPersonMobile': emgMobile.text.trim(),
        if (emgRelation.text
            .trim()
            .isNotEmpty) 'emergencyPersonRelation': emgRelation.text.trim(),

        if (aadhaar.text
            .trim()
            .isNotEmpty) 'aadhaarCard': aadhaar.text.replaceAll(' ', '').trim(),
        if (accName.text
            .trim()
            .isNotEmpty) 'accountNumber': accName.text.trim(),
        if (ifsc.text
            .trim()
            .isNotEmpty) 'ifscCode': ifsc.text.trim(),
        if (bankName.text
            .trim()
            .isNotEmpty) 'bankName': bankName.text.trim(),
        if (upi.text
            .trim()
            .isNotEmpty) 'upiId': upi.text.trim(),
        if (langs.isNotEmpty) 'languages': langs.toSet().join(','),
        if (experience != null &&
            experience!.isNotEmpty) 'experience': experience!,
        if (gender.value != null && (gender.value ?? '')
            .toString()
            .isNotEmpty) 'gender': gender.value ?? '',
        // pricing fields (only include if non-null/non-empty)
        if (oneSessionPrice != null &&
            oneSessionPrice!.isNotEmpty) 'oneSessionPrice': oneSessionPrice!,
        if (monthlySessionPrice != null && monthlySessionPrice!
            .isNotEmpty) 'monthlySessionPrice': monthlySessionPrice!,
        // operational flags / defaults expected by API:
        'isAvailable': 'true',
        'mode': 'offline',
        'isKyc': 'true',
        'commission': '10',
      };

      // Build files map with backend file keys
      final Map<String, File> files = {};
      try {
        if (selfiePath != null && selfiePath!.isNotEmpty) {
          final f = File(selfiePath!);
          if (await f.exists()) files['trainerImageURL'] = f;
        }
        if (aadhaarPhotofrontPath != null &&
            aadhaarPhotofrontPath!.isNotEmpty) {
          final f = File(aadhaarPhotofrontPath!);
          if (await f.exists()) files['aadhaarFrontImageURL'] = f;
        }
        if (aadhaarPhotobackPath != null && aadhaarPhotobackPath!.isNotEmpty) {
          final f = File(aadhaarPhotobackPath!);
          if (await f.exists()) files['aadhaarBackImageURL'] = f;
        }

        // signature bytes -> temp file and send as esignImageURL
        if (signaturePng != null && signaturePng!.isNotEmpty) {
          final dir = await getTemporaryDirectory();
          final tmp = File('${dir.path}/esign_${DateTime
              .now()
              .millisecondsSinceEpoch}.png');
          await tmp.writeAsBytes(signaturePng!);
          files['esignImageURL'] = tmp;
        }
      } catch (e) {
        debugPrint('Error preparing files for KYC: $e');
      }

      debugPrint('KYC submit - trainerId (raw): $trainerId');
      debugPrint('KYC submit - fields keys: ${fields.keys.toList()}');
      debugPrint('KYC submit - files: ${files.keys.toList()}');

      final savedToken = (await SharedPreferences.getInstance()).getString(
          'fitstreet_token') ?? '';
      final fitApi = FitstreetApi(
          'https://api.fitstreet.in', token: savedToken);

      // Call multipart update
    final streamed = await fitApi.updateTrainerProfileMultipart(
      trainerId, fields: fields, files: files.isEmpty ? null : files);
      final resp = await http.Response.fromStream(streamed);

      debugPrint(
          'KYC submit -> status: ${resp.statusCode}, body: ${resp.body}');
      dynamic body;
      try {
        body = jsonDecode(resp.body);
      } catch (_) {
        body = resp.body;
      }

      if (resp.statusCode == 200 || resp.statusCode == 201) {
        // Update local cached profile (IDs, name, email etc.)
        try {
          await auth.fetchTrainerProfile(trainerId);
        } catch (e) {
          debugPrint('fetchTrainerProfile after KYC failed: $e');
        }

        // Sync specialization proofs to avoid duplicates
        try {
          // Delete removed ones first
          final currentIds = professionalRows.map((r) => r.proofId).whereType<String>().toSet();
          final toDelete = _loadedProofIds.difference(currentIds);
          for (final idToDelete in toDelete) {
            try { await fitApi.deleteSpecializationProof(trainerId, idToDelete); } catch (_) {}
          }

          // Create or replace per row
          for (final row in professionalRows) {
            final spec = row.specialization?.trim();
            if (spec == null || spec.isEmpty) continue;
            final certPath = row.certificatePhotoPath;
            final certName = row.certificateName.text.trim();
            final isUrl = (certPath != null) && (certPath.toLowerCase().startsWith('http://') || certPath.toLowerCase().startsWith('https://'));

            if (row.proofId != null) {
              if (certPath != null && certPath.isNotEmpty && !isUrl) {
                try { await fitApi.deleteSpecializationProof(trainerId, row.proofId!); } catch (_) {}
                final f = File(certPath);
                if (await f.exists()) {
                  await fitApi.createSpecializationProof(trainerId, spec, f, certificateName: certName.isEmpty ? null : certName);
                } else {
                  await fitApi.createSpecializationProofMinimal(trainerId, spec, certificateName: certName.isEmpty ? null : certName);
                }
              }
            } else {
              if (certPath != null && certPath.isNotEmpty && !isUrl) {
                final f = File(certPath);
                if (await f.exists()) {
                  await fitApi.createSpecializationProof(trainerId, spec, f, certificateName: certName.isEmpty ? null : certName);
                } else {
                  await fitApi.createSpecializationProofMinimal(trainerId, spec, certificateName: certName.isEmpty ? null : certName);
                }
              } else {
                await fitApi.createSpecializationProofMinimal(trainerId, spec, certificateName: certName.isEmpty ? null : certName);
              }
            }
          }

          // Refresh local proof snapshot
          await _prefillSpecializationsFromServer(trainerId);
        } catch (e) {
          debugPrint('Error while syncing specialization proofs: $e');
        }


        _toast('KYC uploaded successfully.');
        return true;
      } else {
        String msg = 'Failed to submit KYC (${resp.statusCode})';
        try {
          if (body is Map) {
            msg = (body['message'] ?? body['error'] ?? body['msg'] ?? msg).toString();
          } else if (resp.body.isNotEmpty) {
            msg = resp.body;
          }
        } catch (_) {}
        _toast(msg);
        return false;
      }
    } catch (e, st) {
      debugPrint('KYC upload exception: $e\n$st');
      _toast('Error uploading KYC: ${e.toString()}');
      return false;
    } finally {
      if (mounted) setState(() => _uploading = false);
    }
  }

  // --------------------
  // Partial step save helpers
  // --------------------
  Future<String?> _getTrainerId() async {
    try {
      final auth = context.read<AuthManager>();
      final id = await auth.getApiTrainerId();
      if (id != null && id.isNotEmpty) return id;
    } catch (_) {}
    final sp = await SharedPreferences.getInstance();
    return sp.getString('fitstreet_trainer_db_id') ?? sp.getString('fitstreet_trainer_id');
  }

  Future<FitstreetApi> _api() async {
    final token = (await SharedPreferences.getInstance()).getString('fitstreet_token') ?? '';
    return FitstreetApi('https://api.fitstreet.in', token: token);
  }

  Future<bool> _saveStepIdentity() async {
    if (_savingPartial) return false;
    setState(() => _savingPartial = true);
    try {
      final trainerId = await _getTrainerId();
      if (trainerId == null || trainerId.isEmpty) {
        _toast('Trainer id missing.');
        return false;
      }
      // Enforce mandatory images for identity save
      if (selfiePath == null || selfiePath!.isEmpty ||
          aadhaarPhotofrontPath == null || aadhaarPhotofrontPath!.isEmpty ||
          aadhaarPhotobackPath == null || aadhaarPhotobackPath!.isEmpty) {
        _toast('Selfie, Aadhaar front and back are required.');
        return false;
      }
      // Convert DOB
      String? dobIso;
      final txt = dob.text.trim();
      if (txt.isNotEmpty && RegExp(r'^\d{2}/\d{2}/\d{4}$').hasMatch(txt)) {
        final parts = txt.split('/');
        dobIso = "${parts[2]}-${parts[1].padLeft(2,'0')}-${parts[0].padLeft(2,'0')}";
      } else if (txt.isNotEmpty) {
        dobIso = txt;
      }
      final fields = <String, dynamic>{
        if (fullName.text.trim().isNotEmpty) 'fullName': fullName.text.trim(),
        if (mobile.text.trim().isNotEmpty) 'mobileNumber': mobile.text.trim(),
  if (bioData.text.trim().isNotEmpty) 'bioData': bioData.text.trim(),
        if (email.text.trim().isNotEmpty) 'email': email.text.trim(),
        if (dobIso != null && dobIso.isNotEmpty) 'dob': dobIso,
        if (gender.value != null && (gender.value ?? '').isNotEmpty) 'gender': gender.value,
        if (pincode.text.trim().isNotEmpty) 'pincode': pincode.text.trim(),
        if (city.text.trim().isNotEmpty && city.text.trim() != '—') 'city': city.text.trim(),
        if (stateCtrl.text.trim().isNotEmpty && stateCtrl.text.trim() != '—') 'state': stateCtrl.text.trim(),
        'isAddressSame': sameAsPermanent ? 'true' : 'false',
        if (!sameAsPermanent && currentPincode.text.trim().isNotEmpty) 'currentPincode': currentPincode.text.trim(),
        if (!sameAsPermanent && currentCity.text.trim().isNotEmpty && currentCity.text.trim() != '—') 'currentCity': currentCity.text.trim(),
        if (!sameAsPermanent && currentState.text.trim().isNotEmpty && currentState.text.trim() != '—') 'currentState': currentState.text.trim(),
        if (sameAsPermanent && pincode.text.trim().isNotEmpty) 'currentPincode': pincode.text.trim(),
        if (sameAsPermanent && city.text.trim().isNotEmpty && city.text.trim() != '—') 'currentCity': city.text.trim(),
        if (sameAsPermanent && stateCtrl.text.trim().isNotEmpty && stateCtrl.text.trim() != '—') 'currentState': stateCtrl.text.trim(),
        if (addrPermanent.text.trim().isNotEmpty) 'address': addrPermanent.text.trim(),
        if (!sameAsPermanent && addrCurrent.text.trim().isNotEmpty) 'currentAddress': addrCurrent.text.trim(),
        if (sameAsPermanent && addrPermanent.text.trim().isNotEmpty) 'currentAddress': addrPermanent.text.trim(),
        if (emgName.text.trim().isNotEmpty) 'emergencyPersonName': emgName.text.trim(),
        if (emgMobile.text.trim().isNotEmpty) 'emergencyPersonMobile': emgMobile.text.trim(),
        if (emgRelation.text.trim().isNotEmpty) 'emergencyPersonRelation': emgRelation.text.trim(),
        if (aadhaar.text.trim().isNotEmpty) 'aadhaarCard': aadhaar.text.replaceAll(' ','').trim(),
      };
      final files = <String, File>{};
      if (selfiePath != null && selfiePath!.isNotEmpty) {
        final f = File(selfiePath!); if (await f.exists()) files['trainerImageURL'] = f;
      }
      if (aadhaarPhotofrontPath != null && aadhaarPhotofrontPath!.isNotEmpty) {
        final f = File(aadhaarPhotofrontPath!); if (await f.exists()) files['aadhaarFrontImageURL'] = f;
      }
      if (aadhaarPhotobackPath != null && aadhaarPhotobackPath!.isNotEmpty) {
        final f = File(aadhaarPhotobackPath!); if (await f.exists()) files['aadhaarBackImageURL'] = f;
      }
      final api = await _api();
      final streamed = await api.updateTrainerProfileMultipart(trainerId, fields: fields, files: files.isEmpty ? null : files);
      final resp = await http.Response.fromStream(streamed);
      if (resp.statusCode == 200 || resp.statusCode == 201) {
        _toast('Identity saved');
        return true;
      }
      _toast('Save failed (${resp.statusCode})');
      return false;
    } catch (e) {
      _toast('Error saving identity: $e');
      return false;
    } finally {
      if (mounted) setState(() => _savingPartial = false);
    }
  }

  Future<bool> _saveStepBank() async {
    if (_savingPartial) return false;
    setState(() => _savingPartial = true);
    try {
      final trainerId = await _getTrainerId();
      if (trainerId == null || trainerId.isEmpty) {
        _toast('Trainer id missing.');
        return false;
      }
      final fields = <String, dynamic>{
        if (accName.text.trim().isNotEmpty) 'accountNumber': accName.text.trim(),
        if (ifsc.text.trim().isNotEmpty) 'ifscCode': ifsc.text.trim(),
        if (bankName.text.trim().isNotEmpty) 'bankName': bankName.text.trim(),
        if (branch.text.trim().isNotEmpty) 'branch': branch.text.trim(),
        if (upi.text.trim().isNotEmpty) 'upiId': upi.text.trim(),
      };
      final api = await _api();
      final streamed = await api.updateTrainerProfileMultipart(trainerId, fields: fields, files: null);
      final resp = await http.Response.fromStream(streamed);
      if (resp.statusCode == 200 || resp.statusCode == 201) {
        _toast('Bank details saved');
        return true;
      }
      _toast('Save failed (${resp.statusCode})');
      return false;
    } catch (e) {
      _toast('Error saving bank: $e');
      return false;
    } finally {
      if (mounted) setState(() => _savingPartial = false);
    }
  }

  Future<bool> _saveStepProfessional() async {
    if (_savingPartial) return false;
    setState(() => _savingPartial = true);
    try {
      final trainerId = await _getTrainerId();
      if (trainerId == null || trainerId.isEmpty) {
        _toast('Trainer id missing.');
        return false;
      }
      // languages
      final langs = trainingLangs.where((l) => l.toLowerCase() != 'other').map((s)=>s.trim()).where((s)=>s.isNotEmpty).toList();
      if (trainingLangs.any((l)=> l.toLowerCase()=='other') && otherLangCtrl.text.trim().isNotEmpty) {
        langs.addAll(otherLangCtrl.text.split(RegExp(r'[,;]')).map((s)=>s.trim()).where((s)=>s.isNotEmpty));
      }
      final fields = <String, dynamic>{
        if (experience != null && experience!.isNotEmpty) 'experience': experience,
        if (langs.isNotEmpty) 'languages': langs.toSet().join(','),
        if (oneSessionPrice != null && oneSessionPrice!.isNotEmpty) 'oneSessionPrice': oneSessionPrice,
        if (monthlySessionPrice != null && monthlySessionPrice!.isNotEmpty) 'monthlySessionPrice': monthlySessionPrice,
        // keep defaults
        'isAvailable': 'true',
        'mode': 'offline',
      };
      final api = await _api();
      final streamed = await api.updateTrainerProfileMultipart(trainerId, fields: fields, files: null);
      final resp = await http.Response.fromStream(streamed);
      if (!(resp.statusCode == 200 || resp.statusCode == 201)) {
        _toast('Save failed (${resp.statusCode})');
        return false;
      }
      // Sync specialization proofs with server
      // Delete removed ones
      final currentIds = professionalRows.map((r) => r.proofId).whereType<String>().toSet();
      final toDelete = _loadedProofIds.difference(currentIds);
      for (final idToDelete in toDelete) {
        try { await api.deleteSpecializationProof(trainerId, idToDelete); } catch (_) {}
      }

      // Create or replace
      for (final row in professionalRows) {
        final spec = row.specialization?.trim();
        if (spec == null || spec.isEmpty) continue;
        final certPath = row.certificatePhotoPath;
        final certName = row.certificateName.text.trim();
        final isUrl = (certPath != null) && (certPath.toLowerCase().startsWith('http://') || certPath.toLowerCase().startsWith('https://'));

        try {
          if (row.proofId != null) {
            if (certPath != null && certPath.isNotEmpty && !isUrl) {
              try { await api.deleteSpecializationProof(trainerId, row.proofId!); } catch (_) {}
              final f = File(certPath);
              if (await f.exists()) {
                final res = await api.createSpecializationProof(trainerId, spec, f, certificateName: certName.isEmpty ? null : certName);
                try { final b = jsonDecode(res.body); final pid = (b['data']?['_id'] ?? b['_id'] ?? b['id'])?.toString(); if (pid != null && pid.isNotEmpty) row.proofId = pid; } catch (_) {}
              } else {
                final res = await api.createSpecializationProofMinimal(trainerId, spec, certificateName: certName.isEmpty ? null : certName);
                try { final b = jsonDecode(res.body); final pid = (b['data']?['_id'] ?? b['_id'] ?? b['id'])?.toString(); if (pid != null && pid.isNotEmpty) row.proofId = pid; } catch (_) {}
              }
            } // else no change
          } else {
            if (certPath != null && certPath.isNotEmpty && !isUrl) {
              final f = File(certPath);
              if (await f.exists()) {
                final res = await api.createSpecializationProof(trainerId, spec, f, certificateName: certName.isEmpty ? null : certName);
                try { final b = jsonDecode(res.body); final pid = (b['data']?['_id'] ?? b['_id'] ?? b['id'])?.toString(); if (pid != null && pid.isNotEmpty) row.proofId = pid; } catch (_) {}
              } else {
                final res = await api.createSpecializationProofMinimal(trainerId, spec, certificateName: certName.isEmpty ? null : certName);
                try { final b = jsonDecode(res.body); final pid = (b['data']?['_id'] ?? b['_id'] ?? b['id'])?.toString(); if (pid != null && pid.isNotEmpty) row.proofId = pid; } catch (_) {}
              }
            } else {
              final res = await api.createSpecializationProofMinimal(trainerId, spec, certificateName: certName.isEmpty ? null : certName);
              try { final b = jsonDecode(res.body); final pid = (b['data']?['_id'] ?? b['_id'] ?? b['id'])?.toString(); if (pid != null && pid.isNotEmpty) row.proofId = pid; } catch (_) {}
            }
          }
        } catch (e) {
          debugPrint('Spec proof sync failed for $spec: $e');
        }
      }
      _toast('Professional details saved');
      return true;
    } catch (e) {
      _toast('Error saving professional: $e');
      return false;
    } finally {
      if (mounted) setState(() => _savingPartial = false);
    }
  }
}
